sap.ui.define([
    "sap/ui/core/mvc/Controller",
    'sap/m/MessageToast',
    'sap/ui/model/Filter',
    "sap/ui/model/FilterOperator",
    "sap/m/MessageBox"
], function (Controller, MessageToast, Filter, FilterOperator, MessageBox) {
    "use strict";

    return Controller.extend("com.wl.pp.zhulabel.controller.View1", {

        // Function to open the Production Order Value Help Dialog
        onProductionOrderValueHelp: function () {
            if (!this._oProductionDialog) {
                this._oProductionDialog = sap.ui.xmlfragment("com.wl.pp.zhulabel.fragment.ProductionOrder", this);
                this.getView().addDependent(this._oProductionDialog);
            }
            this._oProductionDialog.open();
        },

        // Function to open the Handling Unit Value Help Dialog
        onhandingValueHelp: function () {

            // Retrieve the Production Order value
            var sProductionOrder = this.getView().byId("idproduction").getValue(); // Adjust "idproduction" as needed

            // Check if Production Order is entered
            if (!sProductionOrder) {
                // Show error message if Production Order is empty
                sap.m.MessageToast.show("Please enter a Production Order before selecting a Handling Unit.");
                return; // Stop further execution
            }
            var oView = this.getView();

            if (!this._oHandingDialog) {
                this._oHandingDialog = sap.ui.xmlfragment("com.wl.pp.zhulabel.fragment.HandlingUnit", this);
                oView.addDependent(this._oHandingDialog);
            }

            // Retrieve the dynamic values from the view or model
            // var sProductionOrder = this.getView().byId("idproduction").getValue(); // Adjust "idproduction" as needed

            // Create filters based on dynamic values
            var aFilters = [];
            if (sProductionOrder) {
                aFilters.push(new Filter("aufnr", FilterOperator.EQ, sProductionOrder));
            }

            // Apply filters to the HU dialog
            var oBinding = this._oHandingDialog.getBinding("items");
            if (oBinding) {
                oBinding.filter(aFilters);
            }

            this._oHandingDialog.open();
        },


        // Function to open the Printer Value Help Dialog
        onPrinterValueHelp: function () {
            var that = this;
            var sPlant = this.getOwnerComponent().getModel("local").getProperty("/selectedPlant");

            if (!this._oValueHelpPrinterDialog) {
                this._oValueHelpPrinterDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
                    title: "Printer",
                    supportMultiselect: false,
                    ok: this._onValueHelpOkPnt.bind(this),
                    cancel: this._onValueHelpCancelPnt.bind(this),
                    afterClose: this._onValueHelpAfterClosePnt.bind(this)
                });

                var oColModel = new sap.ui.model.json.JSONModel({
                    cols: [
                        { label: "Plant", template: "Plant" },
                        { label: "Printer", template: "Printer" },
                        { label: "Printer Description", template: "PrinterDescription" },
                        { label: "Default Printer", template: "DefaultPrinter" }
                    ]
                });
                this._oValueHelpPrinterDialog.getTable().setModel(oColModel, "columns");

                this._oValueHelpPrinterDialog.getTableAsync().then(function (oTable) {
                    oTable.setModel(that.getView().getModel());  // Set the OData model to the table
                    oTable.bindAggregation("rows", {
                        path: "/ZZ1_ZPM_CBO_PRINTER_DETAIL",  // Entity set path
                        filters: [new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPlant)],
                        events: {
                            dataReceived: function () {
                                that._oValueHelpPrinterDialog.update();
                            }
                        }
                    });
                });
            }
            this._oValueHelpPrinterDialog.open();
        },

        _onValueHelpOkPnt: function (oEvent) {
            var aTokens = oEvent.getParameter("tokens");
            if (aTokens && aTokens.length) {
                var oToken = aTokens[0];
                var oCustomData = oToken.getAggregation("customData")[0];
                var sSelectedValue = oCustomData.getProperty("value").Printer;

                this.getView().byId("idprinter").setValue(sSelectedValue);
                this.getOwnerComponent().getModel("local").setProperty("/selectedPrinter", sSelectedValue);
            }
            this._oValueHelpPrinterDialog.close();
        },

        _onValueHelpCancelPnt: function () {
            this._oValueHelpPrinterDialog.close();
        },

        _onValueHelpAfterClosePnt: function () {
            this._oValueHelpPrinterDialog.destroy();
            this._oValueHelpPrinterDialog = null;
        },

        // Functions for Production Order fragment
        handleClosePO: function (oEvent) {
            this.getOwnerComponent().getModel("local").setProperty("/selectedPlant", "");
            var oBinding = oEvent.getSource().getBinding("items");
            if (oBinding) {
                oBinding.filter([]);
            }

            var aContexts = oEvent.getParameter("selectedContexts");
            if (aContexts && aContexts.length) {
                var oPlant = aContexts[0].getObject().werks;
                var oProductionOrder = aContexts[0].getObject().aufnr;

                this.byId("idproduction").setValue(oProductionOrder);
                this.getOwnerComponent().getModel("local").setProperty("/selectedPlant", oPlant);
                this.getOwnerComponent().getModel("local").setProperty("/aufnr", oProductionOrder);

                this.onProductionValueChange();

            }
        },
        onProductionValueChange: function () {
            // Fetch the production order number
            var sPO = this.byId("idproduction").getValue();

            // Check if production order number is entered
            if (!sPO) {
                sap.m.MessageToast.show("Please enter a Production Order number.");
                return;
            }

            // OData call to fetch the production order details
            var oModel = this.getOwnerComponent().getModel();
            oModel.read("/ZPP_CDS_HU_LABEL_PRT", {
                filters: [
                    new Filter("aufnr", FilterOperator.Contains, sPO)
                ],
                success: function (oData) {
                    // Check if any results were returned
                    if (oData && oData.results && oData.results.length > 0) {
                        // Populate the selected plant and process further
                        this.getOwnerComponent().getModel("local").setProperty("/selectedPlant", oData.results[0].werks);
                        this._onChangeProduction(oData.results[0].werks);
                    } else {
                        // No results found, show an error message
                        sap.m.MessageToast.show("Production Order does not exist.");
                    }
                    console.log("API Response Data:", oData);
                }.bind(this),
                error: function (oError) {
                    // Handle error in OData call
                    sap.m.MessageToast.show("Failed to fetch Production Order details. Please try again later.");
                    console.error(oError);
                }
            });
        },
        handleSearchPO: function (oEvent) {
            var sValue = oEvent.getParameter("value");
            var aFilter = new Filter({
                filters: [
                    new Filter("aufnr", FilterOperator.Contains, sValue),
                    new Filter("werks", FilterOperator.Contains, sValue)
                ],
                and: false,
            });

            var oBinding = oEvent.getSource().getBinding("items");
            if (oBinding) {
                oBinding.filter([aFilter]);
            }
        },

        _onChangeProduction: function (sPlant) {
            if (!sPlant) {
                sap.m.MessageToast.show("Please enter a valid Plant value.");
                return;
            }

            var oModel = this.getOwnerComponent().getModel();
            if (!oModel) {
                sap.m.MessageToast.show("OData model is not available.");
                return;
            }

            oModel.read("/ZZ1_ZPM_CBO_PRINTER_DETAIL", {
                filters: [
                    new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPlant),
                    new sap.ui.model.Filter("DefaultPrinter", sap.ui.model.FilterOperator.EQ, true)
                ],
                success: function (oData) {
                    var oView = this.getView();
                    var oPrinterField = oView.byId("idprinter");

                    if (oData.results && oData.results.length > 0) {
                        var sPrinter = oData.results[0].Printer;
                        oPrinterField.setValue(sPrinter);
                    } else {
                        oPrinterField.setValue("");
                        sap.m.MessageToast.show("No Default Printer found. Please select Printer manually.");
                    }
                }.bind(this),
                error: function () {
                    sap.m.MessageToast.show("Failed to fetch default printer details.");
                }
            });
        },

        // Functions for Handling Unit fragment
        handleCloseHU: function (oEvent) {
            var oBinding = oEvent.getSource().getBinding("items");
            if (oBinding) {
                oBinding.filter([]);
            }

            var aContexts = oEvent.getParameter("selectedContexts");
            if (aContexts && aContexts.length) {
                var sHandlingUnit = aContexts[0].getObject().exidv;
                this.byId("idhand").setValue(sHandlingUnit);
            }
        },

        handleSearchHU: function (oEvent) {
            var sValue = oEvent.getParameter("value");
            var aFilter = new Filter({
                filters: [
                    new Filter("exidv", FilterOperator.Contains, sValue),
                    new Filter("vemng", FilterOperator.Contains, sValue),
                    new Filter("vemeh", FilterOperator.Contains, sValue)
                ],
                and: false,
            });

            var oBinding = oEvent.getSource().getBinding("items");
            if (oBinding) {
                oBinding.filter([aFilter]);
            }
        },

        // Function to fetch the inputted data and call the S4 API to send the bartender details
        onExecutePress: function () {
            var sPO = this.byId("idproduction").getValue(),
                sHU = this.byId("idhand").getValue(),
                sPrinter = this.byId("idprinter").getValue(),
                sLabel = this.byId("idlabels").getValue();

            if (!sPO || !sHU || !sPrinter || !sLabel) {
                MessageToast.show("Please fill in the mandatory fields.");
            } else {
                // Check if sLabel is a valid number; default to 1 if it's not provided or is invalid
                var iLabels = parseInt(sLabel, 10);
                if (isNaN(iLabels) || iLabels <= 0) {
                    iLabels = 1;  // Default to 1 if the input is invalid
                }

                // Form payload
                var oPayload = {
                    "productionorder": sPO,
                    "handlingunit": sHU,
                    "BartenderPrinter": sPrinter,
                    "Nooflabels": sLabel
                };

                // Show a busy indicator while processing the API request
                sap.ui.core.BusyIndicator.show(0);
                // Call API ZPP_CDS_I_HU_LABEL_PRINT
                this.valueprinter = oPayload.BartenderPrinter
                var oModel = this.getView().getModel(); // Assuming the OData model is set to the view
                oModel.create("/ZPP_CDS_I_HU_LABEL_PRINT", oPayload, {
                    success: function (oData, response) {
                        // Hide the busy indicator on success
                        sap.ui.core.BusyIndicator.hide();
                        sap.m.MessageBox.success(`Label was successfully sent to Printer : ${oData.BartenderPrinter} `); // \n Status: ${oData.RESP_TYPE} \n Message: ${oData.response}` );

                        console.log("OData Service Response:", oData);
                    },

                    error: function (oError) {
                        // Hide the busy indicator on error
                        sap.ui.core.BusyIndicator.hide();
                        MessageBox.error(
                            `Label was not sent to printer ${this.valueprinter}: Please contact Westlake IS team for error resolution`,
                        );

                    }.bind(this)



                });
            }
        }
    });
});
