sap.ui.define([
	"comwlpp/zhulabel/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
